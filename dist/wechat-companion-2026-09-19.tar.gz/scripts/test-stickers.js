// 验证表情包库：列出、精确匹配、模糊匹配、读取。
import { listStickers, findSticker, readSticker, stickerStats, hasStickers } from '../src/soul/stickers.js';

let pass = 0, fail = 0;
const check = (name, cond, extra = '') => {
  if (cond) { console.log(`  ✓ ${name}`); pass++; }
  else { console.log(`  ✗ ${name} ${extra}`); fail++; }
};

console.log('表情包库');
console.log('═'.repeat(64));

const stats = stickerStats();
console.log('库里有', stats.count, '个:', stats.names.join('、'));
check('能列出表情包', stats.count > 0, '库是空的');

console.log('');
console.log('匹配测试（模型记不准名字时要能兜住）');
const cases = [
  ['晚安猫', '晚安猫', '精确'],
  ['晚安猫咪', '晚安猫', '多了个字 → 应匹配到最像的'],
  ['猫', '晚安猫', '只说了一个字'],
  ['笑死', '笑死', '精确'],
  ['笑', '笑死', '部分'],
  ['完全不存在的名字xyz', null, '实在没有 → 该返回 null 或兜底'],
  ['摸鱼', '摸鱼', '精确'],
];
for (const [want, expect, note] of cases) {
  const got = findSticker(want);
  const ok = expect === null ? true : got?.name === expect;
  if (ok) pass++; else fail++;
  console.log(`  ${ok ? '✓' : '✗'} "${want}" → ${got ? got.name : 'null'}   (${note})`);
}

console.log('');
const empty = findSticker('');
check('空名字随机挑一个', !!empty, '应该能随机挑');

const spec = findSticker('晚安猫');
check('能拿到文件路径', !!spec?.path);
check('能识别 mime', spec?.mime === 'image/png', `实际 ${spec?.mime}`);
const data = readSticker(spec);
check('能读出内容', !!data?.data?.length, '读不出来');
check('mime 正确', data?.mime === 'image/png');

console.log('');
console.log('═'.repeat(64));
console.log(`通过 ${pass} / ${pass + fail}`);
process.exit(fail ? 1 : 0);
